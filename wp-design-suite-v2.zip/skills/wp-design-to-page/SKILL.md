---
name: wp-design-to-page
description: Use this skill when the user uploads a design (mockup image, screenshot, Figma export, or HTML) and wants it built or rebuilt as a WordPress page in whatever page builder is active — Elementor, Gutenberg, Classic, Divi, Beaver Builder, WPBakery, or Oxygen. Triggers include "build this design", "turn this mockup into a page", "recreate this layout in Elementor", "here's the design, make it a page", "rebuild this section to match the design". It interprets the design into a structured layout spec, applies brand tokens, generates the active builder's native format, writes via the correct site's WordPress connector, and verifies. Run wp-builder-detect first to lock the target site and know the target builder. Set fidelity expectations honestly per builder.
---

# WP Design to Page

Builds a design into a live WordPress page in the active builder. This is the most ambitious skill in the suite — be honest about fidelity, work iteratively, and always verify against the live page.

## Fidelity expectations (tell the user upfront)
Interpreting a design and emitting a builder's native format is not one-shot magic. Fidelity depends on source and builder:

**By source:** structured (Figma tokens/HTML) > flat image (screenshot/PNG). A flat image means inferring structure, exact measurements, and fonts — expect iteration.

**By builder:** Gutenberg (HIGH) > Divi / WPBakery (MEDIUM) > Elementor / Oxygen (MEDIUM-LOW) > Beaver (LOW, structured-update only). See `../../shared/references/builder-data-models.md`.

Say this to the user before building so expectations are set. Then build to the best achievable fidelity and refine.

## Prerequisites
1. **Target site is locked.** `wp-builder-detect` must have produced `wp-target-site.json`; read it and write only through its `connector_key`. Even for a brand-new page (nothing to detect), run `wp-builder-detect` first purely to resolve and lock the site — never create a page on an inferred site. See `../../shared/references/multi-site-targeting.md`.
2. **`wp-builder-detect`** has identified the target builder (existing page to rebuild) OR the user has stated which builder to create in.
3. **Brand tokens** (`brand-tokens.<connector_key>.json`) exist if the design should follow brand — run `wp-brand-reader` if not. If the design IS the brand source, capture tokens from it first.

## Workflow

### 1. Interpret the design into a layout spec
This is Claude's job, not the connector's — the connector writes, it doesn't see. Produce a builder-agnostic spec:
```json
{
  "sections": [
    {
      "role": "hero",
      "layout": "two-column, text left / image right",
      "background": "#0A0A0A",
      "padding_y": "96px",
      "elements": [
        { "type": "heading", "level": 1, "text": "...", "color": "#FFF", "font": "Poppins", "size": "3rem" },
        { "type": "paragraph", "text": "..." },
        { "type": "button", "text": "Get Started", "style": "primary" },
        { "type": "image", "src": "upload-or-media-url", "alt": "..." }
      ]
    }
  ]
}
```
Measure proportions from the image; map colors/fonts to brand tokens where they match (don't duplicate near-identical hexes — snap to the token). Flag anything you're inferring.

### 2. Resolve media
Images in the design need to exist in the media library. Upload via the connector, set alt text, and use the returned URLs/IDs in the spec. Don't reference images that aren't uploaded.

### 3. Generate the builder-native format
Map the spec to the active builder. **Clone-and-modify is the rule** — pull an existing element of each type from a real page in this builder as a shape template, rather than hand-authoring schema from memory (critical for Elementor JSON and Oxygen options). Per builder:
- **Gutenberg** → block markup with valid comment delimiters + matching inner HTML.
- **Divi / WPBakery** → nested shortcodes with required attrs (`_builder_version` for Divi!).
- **Elementor** → `_elementor_data` JSON tree; unique 7-char hex IDs on every element; container or section/column model matching the site's Elementor version.
- **Beaver** → structured node map via the connector's update path only.
- **Oxygen** → shortcode tree + paired options JSON keyed by element id.

### 4. Write
**Confirm the target before the first write.** State it so the user can veto: "About to build into **Acme Corp (acme.com)** — production — a new page 'Landing' in Elementor. Proceed?" Name the site, environment, and page together; require an explicit go-ahead for the first write when the locked site is production. If the connector you're about to write through doesn't match the locked `connector_key`, **stop**.

Back up first (if rebuilding an existing page). Write through the locked site's connector via the builder-content endpoint (postmeta where required). For a large design, write section by section and verify each before continuing — a broken section is then isolated.

### 5. Bust caches & verify
Clear the builder's CSS cache (Elementor `_elementor_css`, Divi/Oxygen file cache). Fetch the page back, confirm the tree round-tripped and the active flag is intact. Then — because this is a visual task — the true test is visual: tell the user to preview, and offer to iterate on specifics ("hero padding too tight", "wrong heading font"). Expect 2–3 refinement passes for image sources.

## Guardrails
- **Right site, every write.** Build only into the locked `connector_key`. Confirm the site + environment before creating or overwriting a page; a page built on the wrong live site is worse than a low-fidelity one.
- Never claim pixel-perfect from a flat image. Set expectations, deliver honestly, iterate.
- Preserve the active builder — don't convert a page from one builder to another unless explicitly asked (that's a migration, not a build, and it's lossy).
- Keep a backup restore point for any rebuild. If a write corrupts the page, restore and report.
- Don't fabricate copy. If the design has placeholder/lorem text, carry it as placeholder and flag it, or ask for real copy.
