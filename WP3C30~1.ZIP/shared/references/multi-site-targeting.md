# Multi-Site Targeting

This suite is designed to manage **many** WordPress sites from one Cowork workspace. Each site is reached through its own connector entry in `.mcp.json` (each site runs the same Claude connector plugin at `/wp-json/claude-connector/v1/mcp`). When more than one is enabled, every skill must be certain **which site** it is reading or writing before it acts. Writing layout to the wrong live site is the single most damaging mistake this suite can make, so site resolution is treated with the same seriousness as backups.

## The core rule

> **One target site is resolved and locked at the start of every task, confirmed with the user when there is any ambiguity, and re-stated in plain language before every write.**

`wp-builder-detect` owns resolution. The write skills (`wp-layout-fix`, `wp-design-to-page`) refuse to run without a resolved target and re-confirm it before touching anything.

## How connectors are named

Each site is one entry under `mcpServers` in `.mcp.json`. Give every entry a stable key and a human `name` that clearly identifies the site — not a generic label:

```json
{
  "mcpServers": {
    "cognitech-wordpress":  { "type": "url", "name": "Cognitech Digital Studio", "url": "https://cognitechdigitalstudio.com/wp-json/claude-connector/v1/mcp" },
    "acme-wordpress":       { "type": "url", "name": "Acme Corp (acme.com)",       "url": "https://acme.com/wp-json/claude-connector/v1/mcp" },
    "riverside-wordpress":  { "type": "url", "name": "Riverside Clinic (staging)", "url": "https://staging.riversideclinic.org/wp-json/claude-connector/v1/mcp" }
  }
}
```

The connector key (e.g. `acme-wordpress`) is how a skill addresses a specific site's tools; the `name` is what gets shown to the user for confirmation. Include the domain in the `name` so two similarly named clients can't be confused, and mark non-production sites explicitly (`(staging)`, `(dev)`).

## Resolving the target (what wp-builder-detect does first)

1. **Enumerate active WP connectors.** List which `*-wordpress` connectors are currently enabled and reachable.
2. **Pick or ask:**
   - **Zero** active → tell the user no WordPress site is connected; stop.
   - **Exactly one** active → that is the target. State it ("Working on **Cognitech Digital Studio**") and continue — no need to ask.
   - **Two or more** active → **ask the user which site**, listing them by `name`. Never guess, never default to the first. If the user's request already names a site unambiguously (e.g. "fix Acme's about page" and only one connector matches "Acme"), you may match it — but echo the match back so a wrong guess is visible.
3. **Match the URL/title to the chosen site only.** Post/page lookups run against the chosen connector, never fanned out across all sites.
4. **Lock it.** Write the resolved target to `wp-target-site.json` in the working directory (schema below). Every downstream skill reads this file instead of re-resolving.

## The lock file: `wp-target-site.json`

```json
{
  "connector_key": "acme-wordpress",
  "site_name": "Acme Corp (acme.com)",
  "site_url": "https://acme.com",
  "resolved_at": "2026-07-02T14:30:00Z",
  "resolved_by": "wp-builder-detect",
  "environment": "production"
}
```

Rules for the lock file:

- **Written by `wp-builder-detect`**, read by everyone.
- If it already exists for a **different** site than the current task implies, do **not** silently overwrite — surface the mismatch ("Last locked site was Acme; this task looks like Riverside. Switch?") and let the user decide.
- Treat it as valid for the current working session only. If significant time has passed, re-confirm the site is still the intended one before writing.
- All per-site artifacts should be namespaced by `connector_key` so multiple sites can coexist in one working directory:
  - brand tokens → `brand-tokens.<connector_key>.json`
  - backups → `backups/<connector_key>/<post-id>-<builder>-<timestamp>.json`

## Confirming before every write

`wp-layout-fix` and `wp-design-to-page` must, immediately before the first write of a task, state the target in a way the user can veto:

> "About to write to **Acme Corp (acme.com)** — production — the About page (post 128, Elementor). Backup saved. Proceed?"

Requirements:

- Name the **site**, the **environment**, and the **page** together. Site alone isn't enough; page alone isn't enough.
- Call out **production** explicitly. If `environment` is production, require an affirmative go-ahead for the first write of the session rather than proceeding silently.
- If the connector key you're about to write through doesn't match `wp-target-site.json`, **stop** — that's a targeting bug, not a normal state.

## Guardrails

- **Never fan a write across sites.** A "batch" always means multiple pages on **one** locked site, never the same change on many sites, unless the user explicitly asks and confirms each site.
- **Production is the default assumption.** If you can't tell whether a site is production or staging, treat it as production and be maximally cautious.
- **A wrong-site write is worse than a wrong-value write.** When anything about the target is ambiguous, ask. This is the cheapest possible moment to catch it.
