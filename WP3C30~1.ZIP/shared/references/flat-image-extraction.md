# Flat-image asset extraction (crop-and-place)

How to handle regions of a flat mockup (PNG/JPG/screenshot) that can't be rebuilt as native builder widgets. Rebuild what you can; **crop-and-place** the rest. Never ship a placeholder box as if it were finished.

## When this applies
Use crop-and-place for any region classified `decorative` in `wp-design-to-page` step 1b:
- Abstract shapes, waves, blobs, gradients-too-complex-for-CSS
- Illustrations, 3D renders, product/hero photography
- Logos or badges that are artwork (not settable as icon-font/SVG)
- Textured or image-based section backgrounds

Do **not** use it for text, buttons, form fields, flat fills, or simple linear/radial gradients — those are cheaper and sharper as native widgets.

## Workflow

### 1. Locate the region
Measure a pixel bounding box `[x, y, w, h]` on the uploaded mockup. Note the source image's true pixel dimensions first (don't measure off a scaled preview). If the mockup is @2x/retina, keep the crop at full resolution — downscale on the page, not at crop time.

### 2. Crop it (sandbox)
Use Pillow or ImageMagick in the sandbox:
```python
from PIL import Image
img = Image.open("mockup.png")
x, y, w, h = 812, 96, 520, 460
img.crop((x, y, x + w, y + h)).save("hero-wave.png")
```
- Export **PNG** to preserve edges.
- If the region sits on a solid backdrop and needs to float transparently elsewhere, key that color to alpha (see step 5). Otherwise keep it opaque and place it on the matching backdrop.
- Give the file a meaningful name (`hero-wave.png`, `team-photo.png`) — it becomes the media title.

### 3. Upload to the WordPress media library
Upload via the connector's media-upload capability (WordPress media library route). Then set alt text + title/caption via the media-meta capability. Capture the returned **attachment ID** and **URL**:
- **ID** → needed by Elementor image widgets, Gutenberg `core/image`, and featured images.
- **URL** → needed for CSS/background-image placements.

### 4. Place it in the builder
- **As foreground art** → an image widget/block bound to the attachment ID.
- **As a section/container background** → the builder's background-image control pointing at the URL (Elementor: `background_background: "classic"` + `background_image: {id, url}`).
- Set object-fit/position and a sensible max-width so the crop scales cleanly; don't stretch beyond its native resolution.

### 5. Transparency (only when needed)
If the art must overlap a different/busy background:
```python
from PIL import Image
im = Image.open("hero-wave.png").convert("RGBA")
key = (11, 10, 24)      # backdrop color to remove
tol = 18
px = im.getdata()
im.putdata([(r,g,b,0) if abs(r-key[0])<tol and abs(g-key[1])<tol and abs(b-key[2])<tol else (r,g,b,a) for (r,g,b,a) in px])
im.save("hero-wave-cut.png")
```
Color-keying is crude — it works for clean solid backdrops, not for soft shadows/anti-aliased edges over gradients. If the cutout looks ragged, **stop and ask the user for the real asset** (transparent PNG or SVG). A ragged cutout is worse than an honest request.

## Fidelity notes to tell the user
- A crop carries its original background; seamless only on a matching backdrop.
- Cropped raster art won't be as crisp as a native SVG and won't recolor with brand tokens.
- Best results: solid/simple backdrops, art delivered at or above display size.
- When in doubt about quality, offer the crop **and** ask for the source asset so they can choose.

## Guardrails
- Upload before placing — never reference a URL/ID that doesn't exist yet.
- One media item per distinct region; name them so the library stays legible.
- Respect the locked target site — upload to the same `connector_key` you're building into.
- Never present a filler/placeholder rectangle in a delivered page as if it were the finished graphic.
