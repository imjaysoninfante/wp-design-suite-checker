# Builder Data Models

How each supported page builder stores its layout, and how to read/write it through the WordPress connector. This is the single source of truth for "where does the layout actually live" — every other skill depends on it.

The connector exposes two relevant capabilities:
- **Builder content** (`detect the builder` / `get and update a page's builder content`) — use this first; it is the intended, safe path.
- **Post meta** (`read or set any post meta value`) — the escape hatch for builders that hide layout in postmeta the builder-content endpoint may not fully round-trip.

Always prefer the builder-content endpoint. Drop to raw postmeta only when a builder below says so, or when a write via builder-content does not round-trip correctly on fetch-back.

## Detection quick reference

Detection is by fingerprint. The connector's detect call should return the builder, but verify against these signatures when reconstructing or when detection is ambiguous (a page may carry data from a builder that is no longer active).

| Builder | Primary storage | Fingerprint |
|---|---|---|
| Gutenberg | `post_content` | HTML block comments `<!-- wp:namespace/block -->` |
| Classic | `post_content` | Raw HTML, no block comments, no shortcodes |
| Elementor | `_elementor_data` postmeta | `_elementor_edit_mode` = `builder`; `_elementor_data` is JSON |
| Divi | `post_content` | `[et_pb_section]` shortcodes; `_et_pb_use_builder` = `on` |
| Beaver Builder | `_fl_builder_data` postmeta | `_fl_builder_enabled` = `1`; layout is serialized PHP objects |
| WPBakery | `post_content` | `[vc_row]` / `[vc_column]` shortcodes; `_wpb_vc_js_status` present |
| Oxygen | `ct_builder_shortcodes` postmeta | `_ct_builder_shortcodes` present; `ct_builder_shortcodes` meta = `true` |

Detection precedence when multiple fingerprints exist: the meta flag that marks the builder *active* wins (`_elementor_edit_mode`, `_et_pb_use_builder`, `_fl_builder_enabled`, `ct_builder_shortcodes`). Stale data without an active flag should be reported, not edited.

---

## Gutenberg (block editor)

**Storage:** `post_content`, as HTML annotated with block comment delimiters.

**Read:** fetch builder content; you get the raw block markup directly.

**Structure:** each block is `<!-- wp:namespace/name {"attr":value} --> ...html... <!-- /wp:namespace/name -->`. Attributes are JSON in the opening comment; the HTML between is the rendered fallback. Core blocks: `core/group`, `core/columns`, `core/column`, `core/heading`, `core/paragraph`, `core/image`, `core/buttons`, `core/spacer`, `core/cover`.

**Write fidelity:** HIGH. Blocks map cleanly from a design spec. Both attribute JSON and inner HTML must stay consistent — the editor trusts the comment attributes, the front end renders the HTML. Write both.

**Brand application:** colors/typography via block attributes (`style.color.background`, `style.typography.fontSize`) or preset slugs (`backgroundColor`, `fontSize`) if the theme.json defines them. Prefer preset slugs when the theme exposes them — they survive theme token changes.

**Gotcha:** invalid block markup triggers "this block contains unexpected content" recovery in the editor. Validate that every opening delimiter has a matching close and attribute JSON parses before writing.

---

## Elementor

**Storage:** `_elementor_data` postmeta — a JSON string (array of section/container objects). NOT in post_content. `post_content` holds a rendered fallback only; editing it does nothing.

**Read:** prefer builder-content endpoint. If it returns rendered HTML rather than the JSON tree, read `_elementor_data` postmeta directly and parse the JSON.

**Structure (classic sections):** array of elements. Each element: `{ "id": "7-char-hex", "elType": "section|column|widget", "settings": {}, "elements": [] }`. Widgets add `"widgetType"` (e.g. `heading`, `image`, `text-editor`, `button`). Hierarchy: section → column → widget. Container layout (Elementor 3.6+) uses `elType: "container"` with flexbox settings instead of section/column.

**IDs:** every element needs a unique 7-character hex `id`. When generating new elements, mint fresh random hex IDs; duplicate IDs corrupt the page.

**Write fidelity:** MEDIUM-LOW from a raw image. The schema is deep, versioned, and setting keys are non-obvious. Strategy: read an existing element of the target type from the same page as a template, clone its setting shape, and modify values. Do not hand-author complex widgets from memory.

**Write path:** set `_elementor_data` to the new JSON string via post meta. Then — critical — bump/clear Elementor's CSS cache so changes render: delete `_elementor_css` postmeta (Elementor regenerates it) or the front end serves stale CSS.

**Brand application:** global colors/fonts live in Elementor kit settings, not per-page. For per-page brand fixes, set `settings.title_color`, `settings.typography_font_family`, `settings.background_color` etc. on individual widgets/sections. Reference `references/elementor-schema.md`.

**Gotcha:** `_elementor_data` is double-encoded in some connector responses (a JSON string inside JSON). Parse defensively. Always fetch-back and re-parse after writing to confirm the tree round-tripped.

---

## Divi

**Storage:** `post_content`, as `[et_pb_*]` shortcodes. `_et_pb_use_builder` = `on` marks it active.

**Structure:** `[et_pb_section][et_pb_row][et_pb_column][et_pb_text]...[/et_pb_text][/et_pb_column][/et_pb_row][/et_pb_section]`. Attributes are shortcode attrs: `[et_pb_text _builder_version="4.x" text_font="||||" background_color="#fff"]`. Content sits between open/close tags.

**Write fidelity:** MEDIUM. Shortcodes are regular and reconstructable, but attribute names are numerous. Clone-and-modify from an existing module of the same type on the page.

**Brand application:** color/font attrs on modules (`background_color`, `text_text_color`, `header_font`, `body_font`). Divi also has a global "Theme Customizer" and "Global Colors" (`gcid-*` references) — respect existing global color IDs rather than hardcoding hex where the page already uses them.

**Gotcha:** Divi requires `_builder_version` on modules; omit it and modules may not render or may lose styling. Preserve the version already in use on the page. After writing post_content, clear Divi's static CSS cache (`et_core_page_resource` / the `et-cache` directory is server-side; via connector, re-save is usually enough, but verify on fetch-back).

---

## Beaver Builder

**Storage:** `_fl_builder_data` (and `_fl_builder_data_settings`) postmeta — serialized PHP objects, NOT JSON, NOT post_content. `_fl_builder_enabled` = `1` marks it active.

**Read:** via builder-content endpoint. Beaver's serialized-PHP format is fragile to hand-edit. If the connector returns a structured/normalized form, work with that. If it returns raw serialized PHP, treat writes with extreme caution.

**Structure:** nodes keyed by unique ID, each a row / column-group / column / module, with `parent` pointers and a `settings` object. It's a flat node map with parent references, not a nested tree.

**Write fidelity:** LOW for raw reconstruction. PHP serialization encodes string lengths; a hand-built string with a wrong length count silently breaks the whole layout. NEVER hand-write serialized PHP. Only modify via: (a) the connector's structured update if it offers one, or (b) changing scalar setting values in place where you can preserve serialization integrity, ideally letting the connector re-serialize.

**Brand application:** module settings carry `bg_color`, `text_color`, font family/size fields. Change values through the structured path only.

**Gotcha:** if you must touch serialized PHP, recompute every `s:<len>:` byte length or the layout dies. Prefer the connector's own update mechanism. Reference `references/beaver-serialization.md` before any raw edit.

---

## WPBakery (WPBakery Page Builder / "Visual Composer" legacy)

**Storage:** `post_content`, as `[vc_row]` / `[vc_column]` shortcodes. `_wpb_vc_js_status` present.

**Structure:** `[vc_row][vc_column width="1/2"][vc_column_text]...[/vc_column_text][/vc_column][/vc_row]`. Nested content shortcodes: `vc_column_text`, `vc_single_image`, `vc_btn`, `vc_custom_heading`. Some inner content is base64-encoded in attributes (e.g. `vc_raw_html` uses base64) — decode before editing, re-encode after.

**Write fidelity:** MEDIUM. Shortcode grammar is regular. Column widths use fraction strings (`1/2`, `1/3`).

**Brand application:** WPBakery leans on `css=".vc_custom_<hash>{...}"` inline attributes for spacing/color and `el_class` for CSS hooks. Brand fixes often land as: (a) `vc_custom_heading` font/color attrs, (b) design-options `css` attribute blocks, or (c) a global Custom CSS option. For consistent brand color, prefer adding `el_class` hooks + theme Custom CSS over hand-editing every `vc_custom_*` hash.

**Gotcha:** the `vc_custom_<hash>` class names are generated; don't invent them. Preserve existing ones and append new rules via Custom CSS.

---

## Oxygen

**Storage:** `ct_builder_shortcodes` postmeta (the shortcode tree) plus `_ct_builder_shortcodes`. Also relevant: `ct_other_template` and the global Oxygen stylesheet stored in an option, not per-page. `ct_builder_shortcodes` meta = `true` marks active.

**Structure:** Oxygen shortcodes `[ct_section][ct_div][ct_headline]...` with a companion JSON options blob (`ct_*` option keys) holding per-element settings keyed by element id. Element settings are largely in the options JSON, not the shortcode attrs.

**Write fidelity:** LOW-MEDIUM. Oxygen splits structure (shortcodes) from styling (options JSON + global stylesheet), so a faithful edit usually touches two places. Clone-and-modify from existing elements.

**Brand application:** most brand styling is global — Oxygen's stylesheet lives in an option (often `ct_style_settings` / a global CSS option) and via reusable "Selectors". For brand consistency prefer editing global selectors over per-element overrides. Per-element brand values go in the options JSON keyed by element id.

**Gotcha:** editing shortcodes without updating the paired options blob leaves styling stale, and vice-versa. After writing, Oxygen caches CSS to files (`uploads/oxygen/css/`); trigger a regeneration (re-save signal) or the front end serves old CSS. Verify on fetch-back.

---

## Universal write protocol

Regardless of builder, every write follows the same safety loop:

1. **Detect** the active builder and confirm it matches the active flag (not stale data).
2. **Back up** — read current builder content / relevant postmeta and save a timestamped copy before any write. Non-negotiable; builder data corruption is hard to reverse without it.
3. **Clone-and-modify**, don't hand-author — pull an existing element of the target type from the same page as a shape template.
4. **Write** via builder-content endpoint first; fall to postmeta only where this file says the builder requires it.
5. **Bust cache** where noted (Elementor `_elementor_css`, Divi/Oxygen file caches).
6. **Fetch back and verify** — re-read, re-parse, confirm the tree round-tripped and the active flag is intact. Report a diff.

If step 6 shows corruption, restore from the step-2 backup immediately.
