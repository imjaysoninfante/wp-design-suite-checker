# Brand Token Schema

The normalized brand contract. `wp-brand-reader` produces this; `wp-layout-fix` and `wp-design-to-page` consume it. Keep it builder-agnostic — mapping to a specific builder happens at write time, not here.

Save as `brand-tokens.json` in the working directory. One file per site/brand.

## Schema

```json
{
  "brand_name": "string",
  "source": "what this was extracted from (pdf filename, url, image)",
  "extracted_at": "ISO 8601 timestamp",
  "colors": {
    "primary":    { "hex": "#1A1A1A", "role": "main brand / headings" },
    "secondary":  { "hex": "#0066CC", "role": "links / accents / CTAs" },
    "accent":     { "hex": "#FF6B35", "role": "highlights" },
    "background": { "hex": "#FFFFFF", "role": "page background" },
    "surface":    { "hex": "#F5F5F5", "role": "cards / sections" },
    "text":       { "hex": "#222222", "role": "body copy" },
    "text_muted": { "hex": "#666666", "role": "secondary text" },
    "palette": ["#1A1A1A", "#0066CC", "#FF6B35"]
  },
  "typography": {
    "heading_font": { "family": "Poppins", "weights": [600, 700], "fallback": "sans-serif" },
    "body_font":    { "family": "Inter",   "weights": [400, 500], "fallback": "sans-serif" },
    "scale": {
      "h1": { "size": "3rem",    "line_height": 1.1,  "weight": 700 },
      "h2": { "size": "2.25rem", "line_height": 1.2,  "weight": 700 },
      "h3": { "size": "1.5rem",  "line_height": 1.3,  "weight": 600 },
      "body": { "size": "1rem",  "line_height": 1.6,  "weight": 400 },
      "small": { "size": "0.875rem", "line_height": 1.5, "weight": 400 }
    }
  },
  "spacing": {
    "unit": "8px",
    "section_padding_y": "80px",
    "container_max_width": "1200px",
    "gutter": "24px"
  },
  "radius": { "sm": "4px", "md": "8px", "lg": "16px" },
  "logo": {
    "primary_url": "media library URL or upload id",
    "clear_space": "min padding around logo",
    "min_width": "120px",
    "usage_notes": "on-light vs on-dark variants"
  },
  "buttons": {
    "primary":   { "bg": "#0066CC", "text": "#FFFFFF", "radius": "8px", "padding": "12px 28px" },
    "secondary": { "bg": "transparent", "text": "#0066CC", "border": "1px solid #0066CC" }
  },
  "confidence": {
    "colors": "high|medium|low",
    "typography": "high|medium|low",
    "spacing": "high|medium|low",
    "notes": "what was inferred vs explicitly stated in the source"
  }
}
```

## Rules

- **Never invent precision you don't have.** If the source only specifies two brand colors, fill those and mark the rest inferred with `confidence.notes`. A honest low-confidence token beats a confident guess that pollutes the whole site.
- **Hex everywhere** for colors, even if the source gave Pantone/RGB/HSL — convert. Keep the original in `confidence.notes` if it matters.
- **Fonts:** capture family + weights actually used. If the source shows a font but names it wrong or it's a lookalike, note the ambiguity; a wrong font family applied site-wide is very visible.
- **Spacing scale:** most brand guides don't state a spacing unit. Infer from repeated measurements (an 8px or 4px base is typical) and mark it inferred.
- The consuming skills read `confidence` before applying — low-confidence tokens should be surfaced to the user before a site-wide write, not applied silently.
