# Native-widget-first mapping

**Rule: every design element maps to the closest builder widget — from core OR from any ACTIVE builder addon (they are equal, first-class sources). The generic HTML/code widget is a last resort, used only when no core or active-addon widget can express the element — and when used, it must be called out to the user.** Addons (ElementsKit, Unlimited Elements, Essential Addons, Happy Addons, JetElements for Elementor; Divi module packs; WPBakery addons; Gutenberg block plugins) exist precisely to cover what core lacks — a search box, a fancy form, a pricing table, an advanced slider. Reach for them before HTML. A page full of HTML widgets is a failure mode: it's unmaintainable in the visual editor, ignores global styles/typography, and defeats the point of using a builder.

## Procedure (in wp-design-to-page step 1b / step 3)
1. **Inventory the builder's real widget set on THIS site — core AND every active addon.** Don't assume the base set: the site may lack Pro but have powerful addons. List active plugins to see which addon packs are enabled (Elementor: Pro, ElementsKit, Unlimited Elements, Essential Addons, Happy Addons, JetElements, Premium Addons; Divi: Divi Supreme, Divi Modules; WPBakery: addon bundles; Gutenberg: block plugins). Treat every active addon's widgets as available. Then confirm the exact widget TYPE/slug via a real instance (see 'Discovering addon widget types' below) before you emit it.
2. **Map each element to a widget** using the tables below. Prefer core; if only an *active* addon provides it, use the addon widget (clone a real instance to get the exact `widgetType`/module slug and settings shape).
3. **Only if nothing fits**, use the HTML/code widget — and tell the user which element needed it and why (e.g. "Elementor core has no search-input widget and no search addon is active, so the search bar is a small HTML block").
4. **Generated or cropped artwork is not an excuse for HTML.** Upload it to the media library and place it through the native **image** widget (or a section background-image) — never paste an `<img>`/inline `<svg>` into an HTML widget.

## Element → widget map

### Elementor
| Design element | Native widget (prefer) | Notes |
|---|---|---|
| Heading / title | `heading` | header_size for level |
| Body copy / paragraph | `text-editor` | |
| Button / CTA | `button` | set `background_color` (not the global) to override theme |
| Image / logo / illustration / generated art | `image` | bind uploaded attachment `{id,url}` |
| Icon | `icon` | icon-font or SVG |
| Feature (icon+title+text) | `icon-box` / ElementsKit `elementskit-icon-box` | |
| List with icons | `icon-list` | |
| Stat / number | `counter` | |
| Tabs / accordion / toggle | `tabs` / `accordion` / `toggle` | core |
| Testimonial / carousel | `testimonial`, `image-carousel`, or addon | |
| Star rating | `rating` | |
| Divider / spacer | `divider` / `spacer` | |
| Social links | `social-icons` | |
| Nav menu | theme header, or `nav-menu` (Pro) / ElementsKit menu | core free has no nav-menu widget |
| Search input | Elementor **Pro** `search-form`, or an active addon's search widget | **not in core free** — HTML fallback only if none active |
| Contact form | the site's form plugin's widget (e.g. Contact Form 7 via `shortcode` widget, or ElementsKit/Elementor Pro form) | |
| Video | `video` | |
| Raw embed / bespoke markup | `html` | last resort |

### Gutenberg
Prefer `core/*` blocks: `core/heading`, `core/paragraph`, `core/buttons`+`core/button`, `core/image`, `core/cover`, `core/columns`, `core/list`, `core/gallery`, `core/embed`, `core/search`, `core/social-links`. Use `core/html` only for markup no block covers.

### Divi
Map to modules: Text, Blurb, Button, Image, Icon, Number Counter, Toggle/Accordion, Tabs, Gallery, Slider, Contact Form, Search. Use the Code module only as a last resort.

### WPBakery
Map to elements: `vc_custom_heading`, `vc_column_text`, `vc_btn`, `vc_single_image`, `vc_icon`, `vc_tta_*` (tabs/accordion), `vc_gallery`. `vc_raw_html` is the last resort.

### Beaver Builder
Use its modules (Heading, Text Editor, Button, Photo, Icon, Callout, Tabs, Accordion) via the connector's structured update. HTML module last resort.

### Oxygen
Use elements (Heading, Text, Button, Image, Icon, Tabs) with their options JSON. Code Block last resort.

## Discovering addon widget types (never invent a slug)
Addon widget type slugs (Elementor `widgetType`, Divi module names, block names) are not guessable and there's no API that lists registered widgets. Emitting a slug that isn't registered makes the builder render a broken "widget not found" box — worse than a clean fallback. So resolve the exact type from a REAL example, in this order:
1. **Clone from an existing instance.** Search the site's pages, posts, and builder-library templates for a place the widget is already used; read that element and copy its exact `widgetType`/module name and settings shape, then modify.
2. **Ask the user to drop one instance.** If the widget isn't used anywhere yet, ask the user to add a single instance of it (e.g. the ElementsKit / Unlimited Elements Search widget) onto the target page in the editor and save. Then read it back, restyle it to match the design, and lock it in.
3. **Only if neither is possible**, fall back to the HTML/code widget for that one element and tell the user which addon widget would replace it if they add a reference instance.

Never ship an invented addon slug. A verified addon widget or an honest fallback — nothing in between.

## Honest fallbacks
When an element genuinely has no widget (a search input on core-only Elementor; a bespoke animated graphic; a complex custom embed), the HTML widget is legitimate — but:
- Use it for **only** that element, not the whole section.
- Keep native widgets for everything around it.
- Tell the user it's an HTML block and why, and offer the native alternative if they install the addon/Pro that provides it.
