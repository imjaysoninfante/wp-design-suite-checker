---
name: wp-brand-reader
description: Use this skill whenever the user wants to extract, capture, or read a brand's visual design system so it can be applied to a WordPress site. Triggers include uploading a brand guide (PDF or image), pointing at an existing website to "match its style", or saying things like "read our branding", "pull the brand colors and fonts", "capture our design system", or "here's our style guide". It produces a normalized brand-tokens.json (colors, typography, spacing, logo, buttons) that the wp-layout-fix and wp-design-to-page skills consume. Use this before applying brand to any page. Do NOT invent brand values the source doesn't support — capture honestly with confidence flags.
---

# WP Brand Reader

Turns a brand source into a structured, reusable token file. The output is builder-agnostic — it describes the brand, not how any builder implements it. Mapping happens later.

Read `../../shared/references/brand-token-schema.md` for the exact output schema. Follow it precisely; downstream skills rely on the field names.

## Sources you'll get

**Brand guide PDF** — the richest source. Extract stated colors (hex/Pantone/RGB → convert all to hex), named fonts + weights, spacing rules, logo usage, button styles. Use the pdf-reading skill to inspect it; rasterize pages if color swatches need visual sampling.

**Image / mockup (PNG/JPG)** — sample dominant colors visually, identify fonts by eye (name the ambiguity — visual font ID is unreliable; flag confidence). Infer spacing from proportions.

**Existing website URL** — fetch the page and read its rendered CSS: computed colors, `font-family` stacks, heading scale, spacing patterns, button styles. This is high-confidence for colors/fonts (they're literally in the CSS) and medium for spacing.

**Uploaded design file** — treat structured exports (Figma CSS/tokens) as high-confidence; treat flat screenshots as image sources.

## Workflow

1. **Identify the source type** and read it with the right tool (pdf-reading skill for PDFs, image view for images, web fetch for URLs).
2. **Extract systematically** in schema order: colors → typography → spacing → radius → logo → buttons. Don't skip a category; mark it `low` confidence and note "not specified" rather than omitting.
3. **Convert all colors to hex.** Preserve original notation in `confidence.notes` if the brand thinks in Pantone.
4. **Assign semantic roles** — don't just dump a palette. Which color is primary/heading, which is the CTA, which is body text. Downstream brand application needs roles, not a bag of hexes.
5. **Set confidence honestly** per category. If the guide names two colors and you inferred five, say so. Low-confidence tokens get surfaced to the user before any site-wide write.
6. **Save the tokens per site.** Because this workspace can hold several sites, namespace the file by the target site's connector key: `brand-tokens.<connector_key>.json` (read `connector_key` from `wp-target-site.json` if it exists; otherwise ask which site these tokens belong to, or save as `brand-tokens.<slug>.json` using a short brand slug). This keeps Acme's palette from overwriting Cognitech's. If a file for that site exists, ask before overwriting — offer to version it (`brand-tokens.<connector_key>-v2.json`). See `../../shared/references/multi-site-targeting.md`.

## Output to the user
Show a compact summary: the palette with roles, the two font families + scale, spacing base, and — prominently — anything you inferred rather than read. Ask them to confirm or correct the low-confidence items. This is the cheapest point to fix a wrong value; after it's applied across a site, it's expensive.

## Guardrails
- A confident wrong value is worse than a flagged guess. Never present inferred spacing/fonts as if the source stated them.
- If asked to read branding off a site you can't fetch (auth-walled), say so and ask for a screenshot or the guide instead.
- Don't apply anything here. This skill only reads and saves tokens. Application is `wp-layout-fix` / `wp-design-to-page`.
