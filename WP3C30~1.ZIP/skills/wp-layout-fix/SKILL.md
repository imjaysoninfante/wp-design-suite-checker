---
name: wp-layout-fix
description: Use this skill when the user wants to fix, clean up, or apply brand consistency to an EXISTING WordPress page's layout — regardless of which page builder is active (Elementor, Gutenberg, Classic, Divi, Beaver Builder, WPBakery, Oxygen). Triggers include "fix the spacing on this page", "this layout is broken/messy", "apply our brand to this page", "the colors are off", "make this consistent with our style guide", "fix the mobile layout". It reads the normalized structure from wp-builder-detect, applies corrections in the active builder's native format via the WordPress connector, busts caches, and verifies the result round-tripped. Always run wp-builder-detect first. Do NOT edit builder data without a verified backup.
---

# WP Layout Fix

Corrects layout problems and applies brand consistency to an existing page, writing changes in whatever builder is active. Fidelity and method depend entirely on the builder — this skill routes to the right approach.

## Prerequisites (enforce these)
1. **`wp-builder-detect` has run** for this page — you need its normalized structure map, the confirmed active builder, and the backup path. If it hasn't, run it first. Detect also produces `wp-target-site.json`; **this skill will not write without it.**
2. **The target site is locked.** Read `wp-target-site.json` and use its `connector_key` for every write. If it's missing, or names a different site than the structure map you're working from, stop and re-run `wp-builder-detect` — never infer the site.
3. **Brand tokens exist** if the task involves brand (`brand-tokens.<connector_key>.json` from `wp-brand-reader`). If applying brand and no tokens exist for this site, run `wp-brand-reader` first.

Read `../../shared/references/builder-data-models.md` for the active builder's write path, `../../shared/references/brand-token-schema.md` for token field names, and `../../shared/references/multi-site-targeting.md` for the site-lock and confirmation rules.

## Workflow

### 1. Diagnose
From the detect skill's `observations` plus the user's complaint, build a concrete fix list. Categories:
- **Spacing** — inconsistent section padding, cramped/blown-out gutters, misaligned columns.
- **Color** — off-brand colors, low-contrast text, inconsistent CTA colors.
- **Typography** — wrong fonts, inconsistent heading scale, oversized/undersized text.
- **Structure** — broken columns, empty containers, orphaned elements.
- **Responsive** — desktop-only fixes that break mobile; check the builder's per-device settings.

State the fix list to the user before writing. For a brand application, show which tokens map to which elements.

### 2. Map fixes to the active builder
This is the crux. Each fix becomes a builder-native edit. Consult the data-models reference and, for the deep cases, the per-builder notes in this skill's `references/`:
- **Gutenberg** → edit block attribute JSON + inner HTML. High fidelity.
- **Divi / WPBakery** → edit shortcode attributes. Clone attribute shape from an existing module.
- **Elementor** → edit `_elementor_data` JSON; clone element shapes; mint fresh hex IDs for new elements; clear `_elementor_css` after.
- **Beaver** → structured update only; NEVER hand-edit serialized PHP (see `references/beaver-notes.md`).
- **Oxygen** → edit shortcodes AND paired options JSON; global styling prefers selectors over per-element.

Prefer **global/token-level** changes over per-element hardcoding where the builder supports it (Elementor kit, Divi global colors, Oxygen selectors, theme.json presets). A brand fix applied at the global layer stays consistent as the site grows; fifty hardcoded hexes drift.

### 3. Back up again if needed
The detect backup is your restore point. If significant time passed or the page changed, re-fetch and re-back-up before writing.

### 4. Write
**Confirm the target before the first write.** State it so the user can veto: "About to write to **Acme Corp (acme.com)** — production — the About page (post 128, Elementor). Backup saved. Proceed?" Name the site, the environment, and the page together; if `wp-target-site.json` says production, require an explicit go-ahead for the first write of the session. If the connector you're about to write through doesn't match the locked `connector_key`, **stop** — that's a targeting bug.

Then apply via the locked site's connector: builder-content endpoint first; drop to postmeta only where the reference says the builder requires it. Write incrementally where possible (section by section) so a failure is isolated and diagnosable.

### 5. Bust caches
- Elementor → delete `_elementor_css` postmeta.
- Divi / Oxygen → trigger CSS regeneration (re-save signal).
- Others → usually none, but verify.

### 6. Verify (mandatory)
Fetch the page back, re-parse, and confirm:
- The active flag is intact (you didn't accidentally deactivate the builder).
- The layout tree round-tripped (no corruption, no dropped elements).
- The specific fixes are present in the data.
Report a before/after diff of what changed. If verification shows corruption, **restore from backup immediately** and report what went wrong.

## Guardrails
- **Right site, every write.** All writes go through the locked `connector_key`. Never write to a site the user didn't confirm; a wrong-site write is worse than a wrong-value one. A "batch" is multiple pages on **one** locked site — never the same change fanned across sites.
- One page at a time unless the user explicitly authorizes a batch. Batch brand rollouts should be proposed and confirmed, not assumed.
- Low-confidence brand tokens: surface them before a site-wide application, per the brand schema.
- If a fix can't be done reliably in the active builder (e.g. Beaver serialized data the connector won't structure-update), say so honestly rather than risking corruption. Offer the fallback: builder-appropriate Custom CSS.
- Never silently change content (copy, images) while fixing layout unless asked.
