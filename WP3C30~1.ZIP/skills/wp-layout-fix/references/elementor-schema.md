# Elementor `_elementor_data` Schema

Deep reference for reading and writing Elementor layouts. Elementor stores everything as a JSON tree in the `_elementor_data` postmeta — not in `post_content`. Read this before generating or editing Elementor elements.

## Top-level shape
`_elementor_data` is a JSON **array** of top-level elements (sections or containers). Each element is a node:

```json
{
  "id": "a1b2c3d",
  "elType": "section",
  "settings": { },
  "elements": [ ],
  "isInner": false
}
```

- `id` — unique 7-char lowercase hex. MUST be unique across the whole page. Duplicate IDs corrupt rendering.
- `elType` — `section`, `column`, `container`, or `widget`.
- `settings` — object of setting keys (see below). Empty `{}` is valid (inherits defaults).
- `elements` — child nodes array.
- `widgetType` — present only when `elType` is `widget` (e.g. `heading`, `image`, `button`).

## Two layout models
Elementor has two structural paradigms depending on version/page:

**Classic (section/column):**
```
section → column → widget
```
Section holds columns; columns hold widgets. Column widths via `settings._column_size` (percentage integer).

**Container (flexbox, 3.6+):**
```
container → widget (or nested container)
```
`elType: "container"` with flex settings (`flex_direction`, `flex_gap`, `content_width`). More modern; check which the page uses and match it — don't mix models within a page.

## Common widget types & key settings

**heading** (`widgetType: "heading"`):
- `title` — the text
- `header_size` — `h1`–`h6`
- `title_color` — hex
- `typography_typography` — must be `"custom"` to enable custom type settings
- `typography_font_family`, `typography_font_size` (`{"unit":"px","size":48}`), `typography_font_weight`

**text-editor** (`widgetType: "text-editor"`):
- `editor` — HTML string of body content

**button** (`widgetType: "button"`):
- `text`, `link` (`{"url":"...","is_external":"","nofollow":""}`)
- `button_background_color` (via `background_color` in some versions), `button_text_color`
- `border_radius` (`{"unit":"px","top":"8",...}`)

**image** (`widgetType: "image"`):
- `image` — `{"url":"...","id":123}` (id is the media library attachment ID)
- `image_size`, `align`

## Setting-key conventions (the tricky part)
- Toggles that gate a group use a `_typography` / `_border` style suffix set to `"custom"` before the sub-settings apply. E.g. to set custom font you must set `typography_typography: "custom"` AND the `typography_*` fields. Setting `typography_font_size` alone does nothing.
- Dimension values are objects: `{"unit":"px","size":80}` or four-side `{"unit":"px","top":"80","right":"0","bottom":"80","left":"0","isLinked":false}`.
- Responsive settings get device suffixes: `padding_tablet`, `padding_mobile`, `title_color_mobile`. Desktop is the bare key.
- Colors are hex strings. Global colors reference `globals` (`"__globals__": {"title_color":"globals/colors?id=primary"}`) — respect existing global refs rather than overwriting with hardcoded hex.

## Editing safely
1. **Clone, don't author.** Read an existing widget of the same type from the page, copy its `settings` shape, change values. The default settings that Elementor omits still matter; starting from a real element avoids missing required scaffolding.
2. **Mint fresh IDs** for any new element: 7 random hex chars, verified not already present in the tree.
3. **Preserve `__globals__`** blocks unless deliberately overriding brand globals.
4. **Match the layout model** already in use (section/column vs container).

## Writing back
1. Serialize the tree to a JSON string.
2. Set `_elementor_data` postmeta to that string.
3. **Delete `_elementor_css` postmeta** — Elementor caches compiled CSS here; stale cache means your changes don't show on the front end. Elementor regenerates it on next load.
4. Confirm `_elementor_edit_mode` is still `builder`.
5. Fetch back, re-parse the JSON (watch for double-encoding — a JSON string inside a JSON response), confirm structure and IDs.

## Failure signs
- Page shows old styling after edit → `_elementor_css` not cleared.
- "Preview could not be loaded" / elements missing → malformed JSON or duplicate IDs.
- Editing does nothing on front end → you edited `post_content` instead of `_elementor_data` (common mistake).
