# Beaver Builder — Serialization Notes & Cautions

Beaver Builder is the highest-risk builder in this suite to edit programmatically. Read this fully before touching `_fl_builder_data`.

## Why it's dangerous
Beaver stores its layout in `_fl_builder_data` postmeta as **PHP-serialized objects**, not JSON. PHP serialization encodes the byte length of every string inline:

```
s:5:"hello"
```

The `5` is the byte length of `hello`. If you change the string to `hello world` but leave `s:5:`, the entire serialized blob becomes unparseable and **the whole page layout is lost** — not just that field. There is no partial recovery from a length-count mismatch.

## The rule
**NEVER hand-edit serialized PHP.** Do not string-replace values inside `_fl_builder_data`. Do not "just change the hex color" in the raw blob. One wrong byte count destroys the page.

## Safe paths (in order of preference)

1. **Connector structured update.** If the WordPress connector offers a structured/normalized way to get and update Beaver builder content (its "get and update a page's builder content" capability), use that exclusively. Let the connector handle serialization. This is the only fully safe write path.

2. **Read-only + Custom CSS.** If the connector can't structure-update Beaver, do NOT force a raw write. Instead:
   - Read the layout for understanding (identify node IDs, module types).
   - Apply brand/layout fixes via **Beaver's Custom CSS** (per-layout, stored separately) or the theme's Custom CSS, targeting Beaver's generated classes (`.fl-node-<id>`, `.fl-module-content`).
   - This achieves most brand fixes (colors, spacing, typography) without ever re-serializing the layout tree.

3. **Full re-serialization (last resort, only if the connector round-trips it).** Only if the connector reliably parses `_fl_builder_data` into a structure and re-serializes on write. Never assemble serialized PHP yourself.

## Structure (for understanding, not hand-editing)
`_fl_builder_data` deserializes to an associative array of nodes keyed by unique node ID. Each node:
- `node` — the ID
- `type` — `row`, `column-group`, `column`, or `module`
- `parent` — parent node ID (flat map with parent pointers, not nested)
- `settings` — object with the module's fields (`bg_color`, typography, spacing)

Node IDs appear on the front end as `fl-node-<id>` classes — this is what makes the Custom CSS path (option 2) reliable: you can target any element precisely without touching the serialized data.

## Targeting with Custom CSS (the safe brand path)
```css
/* Brand the hero heading without re-serializing */
.fl-node-abc123 .fl-heading-text {
  color: #0066CC;
  font-family: "Poppins", sans-serif;
}
/* Fix section spacing */
.fl-node-def456 {
  padding-top: 80px;
  padding-bottom: 80px;
}
```
Get node IDs from the read step; apply via Beaver's layout Custom CSS or theme Custom CSS through the connector's option-setting capability.

## Verify
After any Beaver change:
- Fetch back and confirm `_fl_builder_enabled` is still `1`.
- If you used the structured update, confirm the node count matches (no dropped nodes).
- Confirm the page still renders (the layout didn't collapse to blank).
- If anything looks wrong, restore from the detect-step backup immediately.
