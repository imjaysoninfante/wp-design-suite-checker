---
name: wp-builder-detect
description: Use this skill FIRST whenever a task involves reading, understanding, editing, or fixing the layout of a WordPress page or post, before any layout change is attempted. It resolves and locks WHICH WordPress site the task targets (critical when multiple site connectors are configured), detects which page builder is active (Elementor, Gutenberg/blocks, Classic, Divi, Beaver Builder, WPBakery, or Oxygen), fetches the page's raw builder content, and outputs a normalized structure map plus a safety backup that the wp-layout-fix and wp-design-to-page skills depend on. Trigger it any time the user says things like "fix this page", "what builder is this", "read this page's layout", "apply our brand to this page", or "rebuild this in the builder" — even if they don't name the builder or the site. Do NOT skip this step and edit builder content blind; writing to the wrong site or corrupting builder data is hard to reverse.
---

# WP Builder Detect

The mandatory first step for any WordPress layout work. You cannot safely edit what you haven't correctly identified and backed up. This skill answers four questions: **which site** are we on, which builder is active, what is the page's current structure, and do we have a restore point.

Read `../../shared/references/builder-data-models.md` before running — it defines every builder's storage location and fingerprints. Read `../../shared/references/multi-site-targeting.md` too — it defines how to resolve and lock the target site, which this skill owns.

## Workflow

### 0. Resolve and lock the target site (do this before anything else)
This workspace may have several WordPress sites connected — each is a separate `*-wordpress` connector in `.mcp.json`. Writing to the wrong live site is the worst mistake this suite can make, so establish the target before you resolve a page:

1. **List the active WP connectors.** See which are enabled and reachable.
2. **Pick or ask:**
   - **Zero** connected → tell the user no WordPress site is connected and stop.
   - **Exactly one** → that's the target. State it plainly ("Working on **Cognitech Digital Studio**") and continue.
   - **Two or more** → **ask which site**, listing them by their connector `name`. Never default to the first, never fan the search across all sites. If the user's request already names a site and exactly one connector matches, you may use it — but echo the match back so a wrong guess is catchable.
3. **Lock it.** Write `wp-target-site.json` to the working directory (`connector_key`, `site_name`, `site_url`, `resolved_at`, `environment`) per the multi-site reference. Downstream skills read this instead of re-resolving. If a lock file already exists for a *different* site than this task implies, surface the mismatch and let the user decide — don't silently overwrite.

From here on, run **every** connector call against the locked site's connector only.

### 1. Resolve the target page
On the locked site, use the connector's post/page search to resolve the user's URL / title / post ID / "the about page" to a single post ID. If more than one matches, list candidates and ask which one. Never guess between two pages.

### 2. Detect the active builder
Call the connector's builder-detection capability. Then **verify** against the fingerprints in the data-models reference — a page can carry stale data from a builder that's no longer active. The active flag wins over leftover data:
- Elementor → `_elementor_edit_mode` = `builder`
- Divi → `_et_pb_use_builder` = `on`
- Beaver → `_fl_builder_enabled` = `1`
- Oxygen → `ct_builder_shortcodes` meta = `true`
- Gutenberg → block comments in `post_content`
- WPBakery → `[vc_row]` + `_wpb_vc_js_status`
- Classic → plain HTML, none of the above

If detection and fingerprints disagree, report it and ask before proceeding — don't edit ambiguous data.

### 3. Fetch raw builder content
Pull the actual layout data from where that builder stores it (per the reference). For Elementor/Beaver/Oxygen this may mean reading postmeta directly if the builder-content endpoint returns only rendered HTML. Parse it into memory:
- Gutenberg/Divi/WPBakery → parse from `post_content`
- Elementor → parse `_elementor_data` JSON (watch for double-encoding)
- Beaver → structured node map (do not attempt to hand-parse serialized PHP; use the connector's structured form)
- Oxygen → shortcode tree + options JSON

### 4. Back up (non-negotiable)
Save a timestamped copy of the exact raw content/postmeta you fetched to `backups/<connector_key>/<post-id>-<builder>-<timestamp>.json` in the working directory, before returning. Namespacing the backup by `connector_key` keeps sites from colliding. Every downstream write depends on this restore point existing.

### 5. Output a normalized structure map
Produce a builder-agnostic description so the fix/build skills can reason without re-parsing builder internals. Use this shape:

```json
{
  "connector_key": "acme-wordpress",
  "site_name": "Acme Corp (acme.com)",
  "environment": "production",
  "post_id": 123,
  "title": "About Us",
  "builder": "elementor",
  "builder_active_flag_verified": true,
  "backup_path": "backups/acme-wordpress/123-elementor-20260702-1430.json",
  "structure": [
    {
      "type": "section",
      "id": "a1b2c3d",
      "role": "hero",
      "children": [
        { "type": "heading", "text": "...", "level": 1, "color": "#111", "font": "Poppins" },
        { "type": "button", "text": "Contact", "bg": "#0066CC" }
      ],
      "layout_notes": "single column, 80px vertical padding"
    }
  ],
  "observations": ["off-brand accent color #FF0000 on CTA", "inconsistent section padding 40/90/60px"]
}
```

Fill `observations` with anything that looks like a layout or brand problem — this is what makes the fix step fast.

## Output to the user
Report concisely: **which site** (name + production/staging), which builder (and that you verified the active flag), where the backup is, and a short summary of the structure with any red-flag observations. Then hand off — tell the user this page is ready for `wp-layout-fix` or `wp-design-to-page`.

## Guardrails
- Never edit in this skill. Site resolution, detection, and backup only.
- Never run a page/post lookup across multiple sites at once. Resolve the target site first, then query only that connector.
- If multiple WP connectors are active and the user hasn't indicated a site, asking which one is mandatory — not optional.
- If the connector can't read the builder's real storage (e.g. returns only rendered HTML for Elementor and postmeta read fails), say so plainly — downstream editing won't be reliable, and the user should know before investing in a fix.
