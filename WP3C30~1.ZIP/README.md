# WP Design Suite

A Cowork plugin for WordPress design work across **any** active page builder and **any number of sites**. It resolves which site you're working on, reads a brand, detects whichever builder a page uses, and either fixes the existing layout or builds an uploaded design into a live page — writing changes in the builder's native format through a per-site WordPress connector.

Supported builders: **Elementor, Gutenberg (blocks), Classic, Divi, Beaver Builder, WPBakery, Oxygen.**

## The four skills

| Skill | What it does | When it triggers |
|---|---|---|
| **wp-brand-reader** | Extracts colors, fonts, spacing, logo, buttons from a brand guide / site / mockup into a reusable `brand-tokens.json`. | "read our branding", "pull the brand colors", uploading a style guide |
| **wp-builder-detect** | Identifies the active builder, fetches raw layout, saves a backup, outputs a normalized structure map. **Runs first.** | "fix this page", "what builder is this", any layout task |
| **wp-layout-fix** | Fixes spacing/color/type/structure and applies brand to an existing page, in the active builder's format. | "fix the spacing", "apply our brand", "the colors are off" |
| **wp-design-to-page** | Interprets an uploaded design and builds it into a page in the active builder. | "build this mockup", "recreate this in Elementor" |

## How they work together

```
wp-brand-reader ──► brand-tokens.json ─┐
                                       ├─► wp-layout-fix ──► live page
wp-builder-detect ──► structure map ───┘
                          │
                          └───────────► wp-design-to-page ──► live page
```

`wp-builder-detect` is the mandatory first step for any layout change — it resolves and locks the target site, then produces the structure map and, critically, the **backup** every write depends on.

## Managing multiple sites

Each WordPress site is one connector entry in `.mcp.json` — every site runs the same Claude connector plugin at `/wp-json/claude-connector/v1/mcp`. Add a site by adding an entry with a stable key and a clear, domain-bearing `name`:

```json
{
  "mcpServers": {
    "cognitech-wordpress": { "type": "url", "name": "Cognitech Digital Studio (cognitechdigitalstudio.com)", "url": "https://cognitechdigitalstudio.com/wp-json/claude-connector/v1/mcp" },
    "acme-wordpress":      { "type": "url", "name": "Acme Corp (acme.com)",                                   "url": "https://acme.com/wp-json/claude-connector/v1/mcp" },
    "riverside-wordpress": { "type": "url", "name": "Riverside Clinic (staging.riversideclinic.org)",         "url": "https://staging.riversideclinic.org/wp-json/claude-connector/v1/mcp" }
  }
}
```

How the suite keeps writes on the right site:

- **`wp-builder-detect` resolves the site first.** One connector active → it's used automatically. Two or more → you're asked which site, by name; the suite never defaults to one or fans a search across sites.
- **The choice is locked** to `wp-target-site.json` in the working directory; the fix/build skills read it instead of re-resolving.
- **Every write is confirmed** by site + environment + page ("About to write to Acme Corp (acme.com) — production — the About page"). Production writes require an explicit go-ahead.
- **Per-site artifacts are namespaced** so sites never collide: `brand-tokens.<connector_key>.json` and `backups/<connector_key>/…`.

Full rules: `shared/references/multi-site-targeting.md`. Tip: include the domain in each `name` and tag non-production sites `(staging)`/`(dev)`.

## Design philosophy

- **Builder-native writes.** Each builder stores layout differently (post_content shortcodes, `_elementor_data` JSON, serialized PHP). The suite writes to the right place per builder — see `shared/references/builder-data-models.md`.
- **Backup before every write.** Builder data corruption is hard to reverse; every edit has a restore point.
- **Clone-and-modify, not hand-author.** Complex schemas (Elementor JSON, Oxygen options) are built from real elements on the page, not from memory.
- **Honest fidelity.** Image-to-page is iterative, not one-shot. The skills set expectations by builder and refine.
- **Beaver Builder is read-cautious.** Its serialized-PHP format is never hand-edited; fixes go through the connector's structured update or Custom CSS. See `skills/wp-layout-fix/references/beaver-notes.md`.

## Requirements

- Cowork with at least one **WordPress connector** enabled (wired in `.mcp.json`). Ships with the Cognitech Digital Studio connector; add more entries to manage additional sites.
- Each target site must run the Claude connector plugin exposing `/wp-json/claude-connector/v1/mcp`.
- The connector's builder-content and post-meta capabilities are what make headless editing possible. If it can't reach a builder's real storage, the affected skill will say so rather than risk corruption.

## Install

Install the `.plugin` file in Cowork (Plugins → install from file), or point Cowork at the GitHub repo. Enable the WordPress connector when prompted.

## Layout

```
wp-design-suite/
├── .claude-plugin/plugin.json
├── .mcp.json
├── README.md
├── shared/references/
│   ├── builder-data-models.md      # how each builder stores layout (core reference)
│   ├── brand-token-schema.md       # the brand-tokens.json contract
│   └── multi-site-targeting.md     # resolving & locking the correct site
└── skills/
    ├── wp-brand-reader/SKILL.md
    ├── wp-builder-detect/SKILL.md
    ├── wp-layout-fix/
    │   ├── SKILL.md
    │   └── references/{elementor-schema.md, beaver-notes.md}
    └── wp-design-to-page/SKILL.md
```
