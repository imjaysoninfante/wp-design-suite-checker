# Native-widget-first mapping

**Rule: every design element maps to the closest native builder widget. The generic HTML/code widget is a last resort, used only when no native or active-addon widget can express the element — and when used, it must be called out to the user.** A page full of HTML widgets is a failure mode: it's unmaintainable in the visual editor, ignores global styles/typography, and defeats the point of using a builder.

## Procedure (in wp-design-to-page step 1b / step 3)
1. **Inventory the builder's real widget set on THIS site.** Don't assume the base set — addons add widgets and the site may lack Pro. List active plugins / builder addons and, via clone-and-modify, read a real page to see which widget types actually exist (e.g. Elementor core vs. Elementor Pro vs. ElementsKit vs. Unlimited Elements; Divi modules; Gutenberg core + block plugins).
2. **Map each element to a widget** using the tables below. Prefer core; if only an *active* addon provides it, use the addon widget (clone a real instance to get the exact `widgetType`/module slug and settings shape).
3. **Only if nothing fits**, use the HTML/code widget — and tell the user which element needed it and why (e.g. "Elementor core has no search-input widget and no search addon is active, so the search bar is a small HTML block").
4. **Generated or cropped artwork is not an excuse for HTML.** Upload it to the media library and place it through the native **image** widget (or a section background-image) — never paste an `<img>`/inline `<svg>` into an HTML widget.

## Element → widget map

### Elementor
| Design element | Native widget (prefer) | Notes |
|---|---|---|
| Heading / title | `heading` | header_size for level |
| Body copy / paragraph | `text-editor` | |
| Button / CTA | `button` | set `background_color` (not the global) to override theme |
| Image / logo / illustration / generated art | `image` | bind uploaded attachment `{id,url}` |
| Icon | `icon` | icon-font or SVG |
| Feature (icon+title+text) | `icon-box` / ElementsKit `elementskit-icon-box` | |
| List with icons | `icon-list` | |
| Stat / number | `counter` | |
| Tabs / accordion / toggle | `tabs` / `accordion` / `toggle` | core |
| Testimonial / carousel | `testimonial`, `image-carousel`, or addon | |
| Star rating | `rating` | |
| Divider / spacer | `divider` / `spacer` | |
| Social links | `social-icons` | |
| Nav menu | theme header, or `nav-menu` (Pro) / ElementsKit menu | core free has no nav-menu widget |
| Search input | Elementor **Pro** `search-form`, or an active addon's search widget | **not in core free** — HTML fallback only if none active |
| Contact form | the site's form plugin's widget (e.g. Contact Form 7 via `shortcode` widget, or ElementsKit/Elementor Pro form) | |
| Video | `video` | |
| Raw embed / bespoke markup | `html` | last resort |

### Gutenberg
Prefer `core/*` blocks: `core/heading`, `core/paragraph`, `core/buttons`+`core/button`, `core/image`, `core/cover`, `core/columns`, `core/list`, `core/gallery`, `core/embed`, `core/search`, `core/social-links`. Use `core/html` only for markup no block covers.

### Divi
Map to modules: Text, Blurb, Button, Image, Icon, Number Counter, Toggle/Accordion, Tabs, Gallery, Slider, Contact Form, Search. Use the Code module only as a last resort.

### WPBakery
Map to elements: `vc_custom_heading`, `vc_column_text`, `vc_btn`, `vc_single_image`, `vc_icon`, `vc_tta_*` (tabs/accordion), `vc_gallery`. `vc_raw_html` is the last resort.

### Beaver Builder
Use its modules (Heading, Text Editor, Button, Photo, Icon, Callout, Tabs, Accordion) via the connector's structured update. HTML module last resort.

### Oxygen
Use elements (Heading, Text, Button, Image, Icon, Tabs) with their options JSON. Code Block last resort.

## Honest fallbacks
When an element genuinely has no widget (a search input on core-only Elementor; a bespoke animated graphic; a complex custom embed), the HTML widget is legitimate — but:
- Use it for **only** that element, not the whole section.
- Keep native widgets for everything around it.
- Tell the user it's an HTML block and why, and offer the native alternative if they install the addon/Pro that provides it.
