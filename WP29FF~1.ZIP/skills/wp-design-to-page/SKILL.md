---
name: wp-design-to-page
description: Use this skill when the user uploads a design (mockup image, screenshot, Figma export, or HTML) and wants it built or rebuilt as a WordPress page in whatever page builder is active - Elementor, Gutenberg, Classic, Divi, Beaver Builder, WPBakery, or Oxygen. Triggers include "build this design", "turn this mockup into a page", "recreate this layout in Elementor". It interprets the design into a layout spec, maps every element to the closest NATIVE builder widget (heading, button, image, icon, tabs) with the HTML/code widget only as a flagged last resort, crops non-reconstructable graphics out of flat mockups into real media, generates the builder's native format, writes via the correct site's connector, and verifies. Run wp-builder-detect first to lock the target site and builder. Set fidelity expectations honestly.
---

# WP Design to Page

Builds a design into a live WordPress page in the active builder. This is the most ambitious skill in the suite — be honest about fidelity, work iteratively, and always verify against the live page.

## Fidelity expectations (tell the user upfront)
Interpreting a design and emitting a builder's native format is not one-shot magic. Fidelity depends on source and builder:

**By source:** structured (Figma tokens/HTML) > flat image (screenshot/PNG). A flat image means inferring structure, exact measurements, and fonts — expect iteration.

**By builder:** Gutenberg (HIGH) > Divi / WPBakery (MEDIUM) > Elementor / Oxygen (MEDIUM-LOW) > Beaver (LOW, structured-update only). See `../../shared/references/builder-data-models.md`.

**Flat images have two kinds of regions.** *Reconstructable* regions (headings, paragraphs, buttons, inputs, flat/gradient backgrounds) are rebuilt as native widgets. *Non-reconstructable* regions (abstract art, illustrations, photos, complex vector graphics, logos-as-artwork) cannot be hand-authored from a flat pixel source — do **not** approximate them with CSS and do **not** silently drop them. Extract them by cropping (see step 2 and `../../shared/references/flat-image-extraction.md`).

Say all of this to the user before building so expectations are set. Then build to the best achievable fidelity and refine.

## Prerequisites
1. **Target site is locked.** `wp-builder-detect` must have produced `wp-target-site.json`; read it and write only through its `connector_key`. Even for a brand-new page (nothing to detect), run `wp-builder-detect` first purely to resolve and lock the site — never create a page on an inferred site. See `../../shared/references/multi-site-targeting.md`.
2. **`wp-builder-detect`** has identified the target builder (existing page to rebuild) OR the user has stated which builder to create in.
3. **Brand tokens** (`brand-tokens.<connector_key>.json`) exist if the design should follow brand — run `wp-brand-reader` if not. If the design IS the brand source, capture tokens from it first.

## Workflow

### 1. Interpret the design into a layout spec
This is Claude's job, not the connector's — the connector writes, it doesn't see. Produce a builder-agnostic spec:
```json
{
  "sections": [
    {
      "role": "hero",
      "layout": "two-column, text left / image right",
      "background": "#0A0A0A",
      "padding_y": "96px",
      "elements": [
        { "type": "heading", "level": 1, "text": "...", "color": "#FFF", "font": "Poppins", "size": "3rem" },
        { "type": "paragraph", "text": "..." },
        { "type": "button", "text": "Get Started", "style": "primary" },
        { "type": "image", "source": "crop", "bbox": [x, y, w, h], "alt": "..." }
      ]
    }
  ]
}
```
Measure proportions from the image; map colors/fonts to brand tokens where they match (don't duplicate near-identical hexes — snap to the token). Flag anything you're inferring.

### 1b. Classify every region: reconstructable vs. decorative
Before writing anything, tag each element in the spec:
- **`reconstructable`** — text, buttons, form fields, icons available as icon-font/SVG, flat fills, and linear/radial gradients. Build these as native widgets.
- **`decorative`** — raster or complex-vector artwork the builder can't reproduce faithfully (abstract shapes, illustrations, product shots, hero imagery, textured backgrounds). Mark each with a `source: "crop"` and a pixel bounding box `[x, y, w, h]` measured on the uploaded mockup.

For each `reconstructable` element, name the **concrete native widget** you'll use (e.g. heading→`heading`, CTA→`button`, stat→`counter`). If an element has no core widget, check the site's active builder addons before reaching for HTML. Tell the user which regions you'll crop-and-place versus rebuild, and note that a crop carries whatever background it sits on (see fidelity caveat below). See `../../shared/references/native-widget-mapping.md`.

### 2. Resolve media (including crop-and-place for flat images)
Every image the layout references must exist in the media library before it's placed.

**Provided assets** (user gave a real image/SVG, or a Figma export): upload via the connector, set alt text, use the returned URL/ID.

**Crop-and-place from a flat mockup** (for each `decorative` region): follow `../../shared/references/flat-image-extraction.md`. In short —
1. Crop the region from the source mockup at its bounding box (Pillow/ImageMagick in the sandbox). Export PNG (keep alpha if the region already has a transparent/solid-color backdrop you can key out).
2. Name it meaningfully (`hero-wave.png`, not `crop1.png`) and upload it to the **WordPress media library** via the connector's media-upload capability. Set alt text and a sensible title/caption via the media-meta capability.
3. Record the returned attachment **ID and URL** — you need the ID for Elementor image widgets / featured images, the URL for CSS background-images.
4. Place it: as an `image` widget, or as a container/section **background-image** when the art is meant to sit behind other content. Namespace nothing globally — these are page assets.

Never reference an image that isn't uploaded, and never leave a "[ placeholder ]" box in a delivered page — either crop-and-place it or explicitly ask the user for the asset if a clean crop isn't possible.

### 3. Generate the builder-native format
**Native widgets first — the HTML/code widget is a last resort.** Every element maps to the closest native widget the *active* builder + its enabled addons provide; only use an HTML/code widget when nothing else can express the element, and when you do, tell the user which element needed it and why. A section built mostly from HTML widgets is a failure — it ignores global styles and can't be edited visually. Full element→widget tables and the addon-detection procedure are in `../../shared/references/native-widget-mapping.md`.

First **inventory this site's real widget set** (don't assume): the base builder may lack Pro, and addons add widgets. List active plugins and clone-and-modify from a real page to confirm which widget types exist before you map. Generated or cropped artwork goes through the **image** widget (uploaded to media) or a section background — never inline `<img>`/`<svg>` in an HTML widget.

**Clone-and-modify is the rule** — pull an existing element of each type from a real page in this builder as a shape template, rather than hand-authoring schema from memory (critical for Elementor JSON and Oxygen options). Per builder (native widgets shown; HTML/code is the fallback of last resort):
- **Gutenberg** → block markup with valid comment delimiters + matching inner HTML; cropped art via `core/image` (with the uploaded attachment ID) or a `core/cover` background.
- **Divi / WPBakery** → nested shortcodes with required attrs (`_builder_version` for Divi!); cropped art via the module's image/background attribute pointing at the uploaded URL.
- **Elementor** → `_elementor_data` JSON tree; unique 7-char hex IDs on every element; container or section/column model matching the site's Elementor version. Cropped art → `image` widget (`image: {id, url}`) or a container with `background_background: "classic"` + `background_image: {id, url}`.
- **Beaver** → structured node map via the connector's update path only.
- **Oxygen** → shortcode tree + paired options JSON keyed by element id.

### 4. Write
**Confirm the target before the first write.** State it so the user can veto: "About to build into **Acme Corp (acme.com)** — production — a new page 'Landing' in Elementor. Proceed?" Name the site, environment, and page together; require an explicit go-ahead for the first write when the locked site is production. If the connector you're about to write through doesn't match the locked `connector_key`, **stop**.

Back up first (if rebuilding an existing page). Write through the locked site's connector via the builder-content endpoint (postmeta where required). For a large design, write section by section and verify each before continuing — a broken section is then isolated.

### 5. Bust caches & verify
Clear the builder's CSS cache (Elementor `_elementor_css`, Divi/Oxygen file cache). Fetch the page back, confirm the tree round-tripped and the active flag is intact. Then — because this is a visual task — the true test is visual: tell the user to preview, and offer to iterate on specifics ("hero padding too tight", "wrong heading font", "re-crop the wave tighter"). Expect 2–3 refinement passes for image sources.

## Fidelity caveat for cropped art
A crop is a flat rectangle of pixels — it carries whatever background it was sitting on. It looks seamless when the region sits on a **solid or simple backdrop** (e.g. a dark hero) and you place it on that same backdrop. It looks wrong when the art must float transparently over a busy or different background — in that case the crop needs a real transparent cutout: try color-keying a solid backdrop to alpha, and if the edges are messy, tell the user honestly and ask for the source asset (PNG/SVG) rather than shipping a boxed-in crop.

## Guardrails
- **Right site, every write.** Build only into the locked `connector_key`. Confirm the site + environment before creating or overwriting a page; a page built on the wrong live site is worse than a low-fidelity one.
- Never claim pixel-perfect from a flat image. Set expectations, deliver honestly, iterate.
- **Native widgets first.** Map every element to its closest native widget (per `native-widget-mapping.md`); use the HTML/code widget only when no native or active-addon widget fits, for that single element, and say so. Put generated/cropped art in an image widget, not inline HTML.
- **No orphan placeholders in delivered pages.** A decorative region is either crop-and-placed or explicitly deferred to the user with a clear ask — never left as a filler box presented as finished.
- Preserve the active builder — don't convert a page from one builder to another unless explicitly asked (that's a migration, not a build, and it's lossy).
- Keep a backup restore point for any rebuild. If a write corrupts the page, restore and report.
- Don't fabricate copy. If the design has placeholder/lorem text, carry it as placeholder and flag it, or ask for real copy.
